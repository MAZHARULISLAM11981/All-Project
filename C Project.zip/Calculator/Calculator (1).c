#include<stdio.h>
#include<math.h>
#include<windows.h>
#include<string.h>

float root();
float square();
float cube();
float cubic_root();
float any_root();
float power();
int factorial();
float sine();
float cosine();
float tangent();
float cot();
float sec();
float cosec();
float sin_inverse();
float cos_inverse();
float tan_inverse();
float add();
float sub();
float mul();
float divition();
float logarithm();
 void registration();



struct calculator
{
    char name[50];
    char mail[50];
    int number;

};


int main()
{

    char a,b[10];
    int i=0;
    registration();
  system("cls");
    printf("\n\n");
    printf("\t\tWhat type of operation do you need?\n\t\t(+)? (-)? (*)? (/)?\n");
    printf("\t\tOr \n\t\t a.Root\n\t\t b.Square\n\t\t c.Cube\n\t\t d.Cubic_root\n\t\t e.Power\n\t\t f.Factorial\n\t\t g.sin\n\t\t h.tan\n\t\t i.cos\n\t\t j.cot\n\t\t k.sec\n\t\t l.cosec\n");
    printf("\t\t m.sin_inverse\n\t\t n.tan_inverse\n\t\t o.cos_inverse\n\t\t p.Any_root\n\t\t q.Logarithm\n\n ");
    printf("\t\tchose your option: ");
    while(1){
    if(scanf("%c",&a)=='NULL')
        return;
    if(a=='+')
    {
        add();
    }
    else if(a=='-')
    {
        sub();
    }
    else if(a=='*')
    {
        mul();
    }
    else if(a=='/')
    {
        divition();
    }
    else if(a=='a')
    {
        root();
    }
    else if(a=='b')
    {
        square();
    }
    else if(a=='c')
    {
        cube();
    }
    else if(a=='d')
    {
        cubic_root();
    }
    else if(a=='e')
    {
        power();
    }
    else if(a=='f')
    {
        factorial();
    }
    else if(a=='g')
    {
        sine();
    }
    else if(a=='h')
    {
        tangent();
    }
    else if(a=='i')
    {
        cosine();
    }
    else if(a=='j')
    {
        cot();
    }
    else if(a=='k')
    {
        sec();
    }
    else if(a=='l')
    {
        cosec();
    }
    else if(a=='m')
    {
        cos_inverse();
    }
    else if(a=='n')
    {
        sin_inverse();
    }
    else if(a=='o')
    {
        tan_inverse();
    }
    else if(a=='p')
    {
        any_root();
    }
    else if(a=='q')
    {
        logarithm();
    }
    else if(a=='1'){return;}
    printf("\n");
    }

    return 0;
}












float root()
{
    double num, root;

    printf("Enter any number to find square root: ");
    scanf("%lf", &num);

    /* Calculate square root of num */
    root = sqrt(num);

    /* Print the resultant value */
    printf("Square root of %.2lf = %.2lf", num, root);

    return 0;
}
float square()
{
    float n,sqr=0;
    printf("\n\t ENTER THE NO.:= ");
    scanf("%f",&n);
    sqr=n*n;
    printf("\n\t SQUARE OF %f is %f .",n,sqr);
}
float cube()
{
    float n,cube=0;
    printf("\n\t ENTER THE NO.:= ");
    scanf("%f",&n);
    cube=n*n*n;
    printf("\n\t CUBE OF %f is %f .",n,cube);
}
float cubic_root()
{
    float num, ans;
    printf("Enter any number: ");
    scanf("%f",&num);
    ans=pow(num, 1/3);
    printf("\n Cube root of %f is: %f",num,ans);
}
float any_root()
{
    float num, ans,pow_nu;
    printf("Enter any number: ");
    scanf("%f",&num);
    printf("Enter power of the number: ");
    scanf("%f",&pow_nu);
    ans=pow(num, pow_nu);
    printf("\n Cube root of %f is: %f",num,ans);
}
float power()
{

    float num,power;
    double ans;
    printf("Enter any number: ");
    scanf("%f",&num);
    printf("\nEnter any its power: ");
    scanf("%f",&power);
    ans=pow(num,power);
    printf("\n Answer of %f is: %lf",num,ans);

}
int factorial()
{
    int n,i;
    long fact=1;
    printf("Write a number:\n");
    scanf("%d",&n);
    for(i=1; i<=n; i++)
    {
        fact=fact*i;
    }
    printf("Factorial is:\n%ld",fact);
}
float sine()
{
    int i;
    printf("Enter any angle: ");
    scanf("%d",&i);
    printf("sin(%d)=%.2f",i,sin(i*M_PI/180));
}
float cosine()
{
    int i;
    printf("Enter any angle: ");
    scanf("%d",&i);
    printf("cos(%d)=%.2f",i,cos(i*M_PI/180));
    return 0;
}
float tangent()
{
    int i;
    printf("Enter any angle: ");
    scanf("%d",&i);
    printf("tan(%d)=%.2f",i,tan(i*M_PI/180));
    return 0;
}
float cot()
{
    int i;
    printf("Enter any angle: ");
    scanf("%d",&i);
    printf("cot(%d)=%.2f",i,1/tan(i*M_PI/180));
    return 0;
}
float sec()
{
    int i;
    printf("Enter any angle: ");
    scanf("%d",&i);
    printf("sec(%d)=%.2f",i,1/cos(i*M_PI/180));
    return 0;
}
float cosec()
{
    int i;
    printf("Enter any angle: ");
    scanf("%d",&i);
    printf("cosec(%d)=%.2f",i,1/sin(i*M_PI/180));
    return 0;
}
float sin_inverse()
{
    float i;
    printf("Enter any angle: ");
    scanf("%f",&i);
    printf("sin inverse(%.2f)=%.2f",i,asin(i*180/M_PI));
    return 0;
}
float cos_inverse()
{
    float i;
    printf("Enter any angle: ");
    scanf("%f",&i);
    printf("cos inverse(%.2f)=%.2f",i,acos(i*180/M_PI));
    return 0;
}
float tan_inverse()
{
    float i;
    printf("Enter any angle: ");
    scanf("%f",&i);
    printf("tan inverse(%.2f)=%.2f",i,atan(i*180/M_PI));
    return 0;
}

float add()
{
    int b,i;
    float s=0,c[1000];
    printf("How many number:\n");
    scanf("%d",&b);
    printf("Enter numbers:\n");
    for(i=0; i<b; i++)
    {
        scanf("%f",&c[i]);
        s=s+c[i];
    }


    printf("Addition:\n %.2f",s);
}
float sub()
{
    int b,i;
    int s,c[1000];
    printf("How many number:\n");
    scanf("%d",&b);
    printf("Enter numbers:\n");
    for(i=0; i<b; i++)
    {
        scanf("%f",&c[i]);
        s=c[0]-c[i];
    }

    printf("Subtraction:\n %.2f",s);
}
float mul()
{
    int b,i;
    int s=1,c[1000];
    printf("How many number:\n");
    scanf("%d",&b);
    printf("Enter numbers:\n");
    for(i=0; i<b; i++)
    {
        scanf("%f",&c[i]);
        s=s*c[i];
    }

    printf("Multiplication:\n %.2f",s);
}
float divition()
{
    int b,i;
    float s,c[1000];
    printf("How many number:\n");
    scanf("%d",&b);
    printf("Enter numbers:\n");
    for(i=0; i<b; i++)
    {
        scanf("%f",&c[i]);
        s=c[0]/c[i];
    }

    printf("Division:\n %f",s);
}
float logarithm()
{
    double a,b;
    printf("Enter any number to find the logarithm value:\n");
    scanf("%lf",&a);
    b= log(a);
    printf("log(%lf) = %lf", a,b);

    return(0);

}

 void registration()
{    struct calculator s[100];

    int i,sum=0,avg;
    FILE* fp;
    fp=fopen("h:\\calculator.txt","a+");
    for(i=0;i<1;i++)
    printf("\n\n\t\t\t Calculator");
    printf("\n\t\tEnter Name: ");
    fflush(stdin);
    gets(s[i].name);
    printf("\n\t\tEnter Number: ");
    scanf("%d",&s[i].number);
    printf("\n\t\tEnter Mail: ");
    fflush(stdin);
    gets(s[i].mail);

    fprintf(fp,"\n%s %d %s",s[i].name,s[i].number,s[i].mail);
    fclose(fp);

}



