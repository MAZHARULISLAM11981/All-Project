#include<stdio.h>
#include<conio.h>
#include<string.h>
#include<stdlib.h>

void registration();

struct c_lang
{
    char name[50];
    char mail[50];
    int number;
};

main()
{
       system("color 3F");

       registration();

       printf("\n\n\n");

	float bangla1, bangla2, english1, english2, math1, math2, physics1, physics2, chemistry1, chemistry2, biology1, biology2, ict;

	float bangla, english, math, physics, chemistry, biology;

	float gpBangla, gpEnglsih, gpMath, gpPhysics, gpChemistry, gpBiology, gpIct;

	printf("------------------------------------- HSC Result Calculaton -----------------------------------------------\n\n\n");
	printf("\t\tPlease Enter Subject wise Marks as 0 to 100 (Where 4th subject is biology):\n\n");

	printf("\tBangla First Paper Mark: ");
	scanf("%f",&bangla1);
	printf("\tBangla Second Paper Mark: ");
	scanf("%f",&bangla2);
	bangla = (bangla1+bangla2)/2;

	printf("\n\n\tEnglish First Paper Mark: ");
	scanf("%f",&english1);
	printf("\tEnglish Second Paper Mark: ");
	scanf("%f",&english2);
	english = (english1+english2)/2;

	printf("\n\n\tMath First Paper Mark: ");
	scanf("%f",&math1);
	printf("\tMath Second Paper Mark: ");
	scanf("%f",&math2);
	math = (math1+math2)/2;

	printf("\n\n\tPhysics First Paper Mark: ");
	scanf("%f",&physics1);
	printf("\tPhysics Second Paper Mark: ");
	scanf("%f",&physics2);
	physics =(physics1+physics2)/2;

	printf("\n\n\tChemistry First Paper Mark: ");
	scanf("%f",&chemistry1);
	printf("\tChemistry Second Paper Mark: ");
	scanf("%f",&chemistry2);
	chemistry = (chemistry1+chemistry2)/2;


	printf("\n\n\tBiology First Paper Mark: ");
	scanf("%f",&biology1);
	printf("\tBiology Second Paper Mark: ");
	scanf("%f",&biology2);
	biology = (biology1+biology2)/2;

	printf("\n\n\tMark of ICT: ");
	scanf("%f",&ict);



//	Bangla Grade Point Calculation
	if(bangla<33)
	{
		gpBangla = 0;
	}
	else if (bangla>=33 && bangla<40)
	{
		gpBangla = 1;
	}
	else if (bangla>=40 && bangla<50)
	{
		gpBangla = 2;
	}
	else if (bangla>=50 && bangla<60)
	{
		gpBangla = 3;
	}
	else if (bangla>=60 && bangla<70)
	{
		gpBangla = 3.5;
	}
	else if (bangla>=70 && bangla<80)
	{
		gpBangla = 4;
	}
	else if (bangla<=100)
	{
		gpBangla = 5;
	}
//	english Grade Point Calculation
	if(english<33)
	{
		gpEnglsih = 0;
	}
	else if (english>=33 && english<40)
	{
		gpEnglsih = 1;
	}
	else if (english>=40 && english<50)
	{
		gpEnglsih = 2;
	}
	else if (english>=50 && english<60)
	{
		gpEnglsih = 3;
	}
	else if (english>=60 && english<70)
	{
		gpEnglsih = 3.5;
	}
	else if (english>=70 && english<80)
	{
		gpEnglsih = 4;
	}
	else if (english<=100)
	{
		gpEnglsih = 5;
	}

//	math Grade Point Calculation
	if(math<33)
	{
		gpMath = 0;
	}
	else if (math>=33 && math<40)
	{
		gpMath = 1;
	}
	else if (math>=40 && math<50)
	{
		gpMath = 2;
	}
	else if (math>=50 && math<60)
	{
		gpMath = 3;
	}
	else if (math>=60 && math<70)
	{
		gpMath = 3.5;
	}
	else if (math>=70 && math<80)
	{
		gpMath = 4;
	}
	else if (math<=100)
	{
		gpMath = 5;
	}


//	physics Grade Point Calculation
	if(physics<33)
	{
		gpPhysics = 0;
	}
	else if (physics>=33 && physics<40)
	{
		gpPhysics = 1;
	}
	else if (physics>=40 && physics<50)
	{
		gpPhysics = 2;
	}
	else if (physics>=50 && physics<60)
	{
		gpPhysics = 3;
	}
	else if (physics>=60 && physics<70)
	{
		gpPhysics = 3.5;
	}
	else if (physics>=70 && physics<80)
	{
		gpPhysics = 4;
	}
	else if (physics<=100)
	{
		gpPhysics = 5;
	}

//	chemistry Grade Point Calculation
	if(chemistry<33)
	{
		gpChemistry = 0;
	}
	else if (chemistry>=33 && chemistry<40)
	{
		gpChemistry = 1;
	}
	else if (chemistry>=40 && chemistry<50)
	{
		gpChemistry = 2;
	}
	else if (chemistry>=50 && chemistry<60)
	{
		gpChemistry = 3;
	}
	else if (chemistry>=60 && chemistry<70)
	{
		gpChemistry = 3.5;
	}
	else if (chemistry>=70 && chemistry<80)
	{
		gpChemistry = 4;
	}
	else if (chemistry<=100)
	{
		gpChemistry = 5;
	}


//	biology Grade Point Calculation	.... Because of 4th subject it dooesn't affect on fail so I directly cut out the GPA
	if(biology<33)
	{
		gpBiology = 0;
	}
	else if (biology>=33 && biology<40)
	{
		gpBiology = 0;
	}
	else if (biology>=40 && biology<50)
	{
		gpBiology = 0;
	}
	else if (biology>=50 && biology<60)
	{
		gpBiology = 1;
	}
	else if (biology>=60 && biology<70)
	{
		gpBiology = 1.5;
	}
	else if (biology>=70 && biology<80)
	{
		gpBiology = 2;
	}
	else if (biology<=100)
	{
		gpBiology = 3;
	}




//	ict Grade Point Calculation
	if(ict<33)
	{
		gpIct = 0;
	}
	else if (ict>=33 && ict<40)
	{
		gpIct = 1;
	}
	else if (ict>=40 && ict<50)
	{
		gpIct = 2;
	}
	else if (ict>=50 && ict<60)
	{
		gpIct = 3;
	}
	else if (ict>=60 && ict<70)
	{
		gpIct = 3.5;
	}
	else if (ict>=70 && ict<80)
	{
		gpIct = 4;
	}
	else if (ict<=100)
	{
		gpIct = 5;
	}



	if((gpBangla==0) || (gpEnglsih==0) || (gpMath==0) || (gpPhysics==0) || (gpChemistry==0) || (gpIct ==0))
	//Because of 4th subject it dooesn't affect on fail so I directly cut out the Biology subject.
	{   system("color 4F");
		printf("\n\tYour are Failed.");
		printf("\n\tYour Grade is:- F \n");

	}

	else
	{
		float gpa;
		gpa = (gpBangla + gpEnglsih + gpMath + gpPhysics + gpChemistry + gpIct)/6;

		if(gpa==5)
            {
               gpa=5;
		    }
        else
        {

            gpa=gpa+(gpBiology/6);
        }

		printf("\n\n\n\tYour result is GPA-%.2f \n \t\tand \n",gpa);

		if(gpa >= 1 && gpa<2)
		{
			printf("Grade- D");
		}
		else if(gpa >= 2 && gpa<3)
		{
			printf("Grade- C");
		}
		else if(gpa >= 3 && gpa<3.5)
		{
			printf("Grade- B");
		}
		else if(gpa >= 3.5 && gpa<4)
		{
			printf("Grade- A-");
		}
		else if(gpa >= 4 && gpa<5)
		{
			printf("Grade- A");
		}
		else if(gpa == 5)
		{
			printf("\tYour Grade Is : A+\n\n");
			printf("This System Developed By : Shila Roy\n\n");
		}
	}
}

	void registration()
{
    struct c_lang s[100];

    int i;
    FILE* fp;
    fp=fopen("c:\\c_lang.txt","a+");
    for(i=0;i<1;i++)
    printf("\n\n\t\t\t \t \t Registration Information \n ");
    printf("----------------------------------------------------------------------------------------------------------");
    printf("\n\n\t\tEnter Your Name: ");
    fflush(stdin);
    gets(s[i].name);
    printf("\n\t\tEnter Your number: ");
    scanf("%d",&s[i].number);
        fflush(stdin);
        printf("\n\t\tEnter Your mail: ");
        gets(s[i].mail);
    fprintf(fp,"\n%s %d %d %s",s[i].name,s[i].number,s[i].mail);
    fclose(fp);
}

