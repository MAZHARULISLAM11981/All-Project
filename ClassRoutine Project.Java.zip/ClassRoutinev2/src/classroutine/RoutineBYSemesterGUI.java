package classroutine;

import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.text.MessageFormat;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class RoutineBYSemesterGUI extends javax.swing.JFrame {
    boolean firstTime=true;
    
    String selectedSection="";
    int takeSemester=0;
    private String lab="";
    
    public RoutineBYSemesterGUI() {
        initComponents();
        cbLab1.setEnabled(false);
        cbLab2.setEnabled(false);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        semesterField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        sectionComboBox = new javax.swing.JComboBox();
        btnFindRoutine = new javax.swing.JButton();
        btnClear = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        cbLab1 = new javax.swing.JCheckBox();
        cbLab2 = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        routineTable = new javax.swing.JTable();
        btnBack = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Access To Routine");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));

        jPanel5.setBackground(new java.awt.Color(204, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Searching By Semester", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Consolas", 1, 20))); // NOI18N

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Consolas", 1, 18))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel2.setText("Enter Semester");

        semesterField.setText("Enter Integer Value");
        semesterField.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseMoved(java.awt.event.MouseEvent evt) {
                semesterFieldMouseMoved(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel6.setText("Select Section");

        sectionComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P" }));
        sectionComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                sectionComboBoxItemStateChanged(evt);
            }
        });

        btnFindRoutine.setBackground(new java.awt.Color(153, 255, 153));
        btnFindRoutine.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnFindRoutine.setText("Find Routine");
        btnFindRoutine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindRoutineActionPerformed(evt);
            }
        });

        btnClear.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        btnClear.setText("Clear");
        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        jLabel7.setText("Select Lab");

        buttonGroup1.add(cbLab1);
        cbLab1.setText("LAB1");

        buttonGroup1.add(cbLab2);
        cbLab2.setText("LAB2");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(btnClear)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnFindRoutine))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 126, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(semesterField, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(sectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                .addGap(14, 14, 14)
                                .addComponent(cbLab1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cbLab2)
                                .addGap(14, 14, 14)))))
                .addGap(19, 19, 19))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(semesterField, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(sectionComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(cbLab1)
                    .addComponent(cbLab2))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFindRoutine)
                    .addComponent(btnClear))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        routineTable.setFont(new java.awt.Font("Consolas", 1, 14)); // NOI18N
        routineTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Class Room Number", "Course Code", "Teacher Initial", "Day", "Time"
            }
        ));
        routineTable.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jScrollPane1.setViewportView(routineTable);

        btnBack.setBackground(new java.awt.Color(0, 204, 204));
        btnBack.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        btnBack.setText("Back");
        btnBack.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(255, 0, 0));
        jButton1.setFont(new java.awt.Font("Consolas", 1, 24)); // NOI18N
        jButton1.setText("Exit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addComponent(btnBack, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(17, 17, 17))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 807, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBack, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 818, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(219, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        setSize(new java.awt.Dimension(856, 507));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void semesterFieldMouseMoved(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_semesterFieldMouseMoved
        if(firstTime==true){
            semesterField.setText("");
            firstTime=false;
        }
    }//GEN-LAST:event_semesterFieldMouseMoved

    private void btnBackActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackActionPerformed
        MainMenu mainMenu = new MainMenu();
        mainMenu.setVisible(true);
        close();
    }//GEN-LAST:event_btnBackActionPerformed

    private void btnClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearActionPerformed
        semesterField.setText("");
        sectionComboBox.setSelectedItem("Select");
        cbLab1.setSelected(false);
        cbLab2.setSelected(false);
    }//GEN-LAST:event_btnClearActionPerformed

    private void btnFindRoutineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindRoutineActionPerformed
        String selectedGroup=sectionComboBox.getSelectedItem().toString();

        if(semesterField.getText().equals("")){
            JOptionPane.showMessageDialog(this, "Please Enter a Semester", "Blank Input", JOptionPane.WARNING_MESSAGE);
        }
        else{ 
            try {
                takeSemester=Integer.parseInt(semesterField.getText());

                if(selectedGroup.equalsIgnoreCase("Select")){
                    selectedSection="";
                }else{
                    selectedSection=selectedGroup;
                }
                if(cbLab1.isSelected()){
                    lab=cbLab1.getText();
                }else if(cbLab2.isSelected()){
                    lab=cbLab2.getText();
                }else{
                    lab="";
                }
                
                if(lab.equalsIgnoreCase("lab1")){
                    findRoutineWithSectionAndLab("lab2", 2); // send the reverse value
                }
                else if(lab.equalsIgnoreCase("lab2")){
                    findRoutineWithSectionAndLab("lab1", 1); // send the reverse value
                }else{
                    findRoutineWithSection();
                }
            } catch (Exception e) {
                DefaultTableModel model = (DefaultTableModel) routineTable.getModel();
                model.setRowCount(0);
                JOptionPane.showMessageDialog(this, "Please Enter Only Integer Values", "Invalid Input", JOptionPane.WARNING_MESSAGE);
            }
        
        }
        
        
    }//GEN-LAST:event_btnFindRoutineActionPerformed

    private void sectionComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_sectionComboBoxItemStateChanged
        String selectedGroup=sectionComboBox.getSelectedItem().toString();
        
        if(selectedGroup.equalsIgnoreCase("select")){
            cbLab1.setEnabled(false);
            cbLab2.setEnabled(false);
            buttonGroup1.clearSelection();
        }else{
            cbLab1.setEnabled(true);
            cbLab2.setEnabled(true);
        }
    }//GEN-LAST:event_sectionComboBoxItemStateChanged

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int choice =JOptionPane.showConfirmDialog(this, "Exit From Class Routine?", "Confirmation", JOptionPane.YES_NO_OPTION);
        if(choice==0){
            System.exit(0);
        }
    }//GEN-LAST:event_jButton1ActionPerformed
           
    
    private void findRoutineWithSection(){
        DefaultTableModel model = (DefaultTableModel) routineTable.getModel();
        // set deafult row as 0 / zero !
        model.setRowCount(0);
        
        if(takeSemester==1){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE111"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE112"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("PHY114"+selectedSection).toLowerCase())){
                    
                                model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                flag=0;
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==2){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE121"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE122"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("MAT113"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("ENG123"+selectedSection).toLowerCase())){
                    
                                    model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                    flag=0;
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==3){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE133"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE231"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("MAT221"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("STA134"+selectedSection).toLowerCase())){
                    
                                    model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                    flag=0;
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==4){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE132"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE213"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE211"+selectedSection).toLowerCase())){
                    
                                    model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                    flag=0;
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==5){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE223"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE222"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE224"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE233"+selectedSection).toLowerCase())){
                    
                                    model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                    flag=0;
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==6){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE131"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE232"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("ACC124"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE212"+selectedSection).toLowerCase())){
                    
                                    model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                    flag=0;
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==7){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE323"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE312"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE322"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE313"+selectedSection).toLowerCase())){
                    
                                    model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                    flag=0;
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==8){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE321"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE333"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE413"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE311"+selectedSection).toLowerCase())){
                    
                                    model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                    flag=0;
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==9){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE412"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE331"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE422"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE424"+selectedSection).toLowerCase())){
                    
                                    model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                    flag=0;
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==10){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE423"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE425"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE426"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE332"+selectedSection).toLowerCase())){
                    
                                    model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                    flag=0;
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==11){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE435"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE421"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE439"+selectedSection).toLowerCase())){
                    
                                    model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                    flag=0;
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else{
            JOptionPane.showMessageDialog(this, "Sorry The System will not able to show the routine for this Semester", "Information", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    
    /*
     * @ Fidn Routine with section and lab 
    */
    
    private void findRoutineWithSectionAndLab(String revLabName, int revLabNo){
        DefaultTableModel model = (DefaultTableModel) routineTable.getModel();
        // set deafult row as 0 / zero !
        model.setRowCount(0);
        
        if(takeSemester==1){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE111"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE112"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("PHY114"+selectedSection).toLowerCase())){

                    if(!Main.routineInfo[i].getCourseCode().toLowerCase().contains(revLabName.toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE111"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE112"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("PHY114"+selectedSection + revLabNo).toLowerCase())
                      ){
                        
                                model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                flag=0;
                    }
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }else if(takeSemester==2){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE121"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE122"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("MAT113"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("ENG123"+selectedSection).toLowerCase())){
                    
                    if(!Main.routineInfo[i].getCourseCode().toLowerCase().contains(revLabName.toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE121"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE122"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("MAT113"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("ENG123"+selectedSection + revLabNo).toLowerCase())     
                      ){
                                    
                                model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                flag=0;
                    }
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==3){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE133"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE231"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("MAT221"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("STA134"+selectedSection).toLowerCase())){
                    
                    if(!Main.routineInfo[i].getCourseCode().toLowerCase().contains(revLabName.toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE133"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE231"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("MAT221"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("STA134"+selectedSection + revLabNo).toLowerCase())
                      ){
                        
                                model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                flag=0;
                    }
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==4){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE132"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE213"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE211"+selectedSection).toLowerCase())){
                   
                    if(!Main.routineInfo[i].getCourseCode().toLowerCase().contains(revLabName.toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE132"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE213"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE211"+selectedSection + revLabNo).toLowerCase())
                      ){
                                    
                                model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                flag=0;
                    }
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==5){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE223"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE222"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE224"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE233"+selectedSection).toLowerCase())){
                    
                    if(!Main.routineInfo[i].getCourseCode().toLowerCase().contains(revLabName.toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE223"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE222"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE224"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE233"+selectedSection + revLabNo).toLowerCase())
                      ){
                        
                                model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                flag=0;
                    }
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==6){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE131"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE232"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("ACC124"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE212"+selectedSection).toLowerCase())){
                    
                    if(!Main.routineInfo[i].getCourseCode().toLowerCase().contains(revLabName.toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE131"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE232"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("ACC124"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE212"+selectedSection + revLabNo).toLowerCase())
                      ){
                        
                                model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                flag=0;
                    }
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==7){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE323"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE312"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE322"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE313"+selectedSection).toLowerCase())){
                    
                    if(!Main.routineInfo[i].getCourseCode().toLowerCase().contains(revLabName.toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE323"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE312"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE322"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE313"+selectedSection + revLabNo).toLowerCase())
                      ){
                     
                                model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                flag=0;
                    }
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==8){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE321"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE333"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE413"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE311"+selectedSection).toLowerCase())){
                    
                    if(!Main.routineInfo[i].getCourseCode().toLowerCase().contains(revLabName.toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE321"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE333"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE413"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE311"+selectedSection + revLabNo).toLowerCase())
                      ){
                     
                                model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                flag=0;
                    }
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==9){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE412"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE331"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE422"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE424"+selectedSection).toLowerCase())){
                    
                    if(!Main.routineInfo[i].getCourseCode().toLowerCase().contains(revLabName.toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE412"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE331"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE422"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE424"+selectedSection + revLabNo).toLowerCase())
                      ){
                     
                                model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                flag=0;
                    }
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==10){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE423"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE425"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE426"+selectedSection).toLowerCase())||
                                Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE332"+selectedSection).toLowerCase())){
                    
                    if(!Main.routineInfo[i].getCourseCode().toLowerCase().contains(revLabName.toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE423"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE425"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE426"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE332"+selectedSection + revLabNo).toLowerCase())
                      ){
                                    
                                model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                flag=0;
                    }
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else if(takeSemester==11){
            int flag=1;
            for(int i=0;i<Main.countRoutineInfo;i++){
                if(Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE435"+selectedSection).toLowerCase())||
                        Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE421"+selectedSection).toLowerCase())||
                            Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE439"+selectedSection).toLowerCase())){
                    
                    if(!Main.routineInfo[i].getCourseCode().toLowerCase().contains(revLabName.toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE435"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE421"+selectedSection + revLabNo).toLowerCase())&&
                       !Main.routineInfo[i].getCourseCode().toLowerCase().contains(("SWE439"+selectedSection + revLabNo).toLowerCase())
                      ){
                     
                                model.addRow(new Object[]{Main.routineInfo[i].getClassRoomNumber(),Main.routineInfo[i].getCourseCode(),Main.routineInfo[i].getTeacherInitial()
                                        ,Main.routineInfo[i].getDay(),Main.routineInfo[i].getTime()});
                                flag=0;
                    }
                }
            }
            if(flag==1){
                JOptionPane.showMessageDialog(this, "Sorry No Matched Subject Found !", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        }
        else{
            JOptionPane.showMessageDialog(this, "Sorry The System will not able to show the routine for this Semester", "Information", JOptionPane.WARNING_MESSAGE);
        }
    }
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RoutineBYSemesterGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RoutineBYSemesterGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RoutineBYSemesterGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RoutineBYSemesterGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RoutineBYSemesterGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack;
    private javax.swing.JButton btnClear;
    private javax.swing.JButton btnFindRoutine;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JCheckBox cbLab1;
    private javax.swing.JCheckBox cbLab2;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable routineTable;
    private javax.swing.JComboBox sectionComboBox;
    private javax.swing.JTextField semesterField;
    // End of variables declaration//GEN-END:variables
    
    private void close(){
        WindowEvent windowClose = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);
        Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(windowClose);
    }
}
