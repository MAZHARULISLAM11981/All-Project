
import java.sql.Connection;
import java.sql.DriverManager;

public class Myconnection {
    static Connection getConnection()
    {
           Connection con = null;
      try {
         Class.forName("org.sqlite.JDBC");
         con = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Showrov\\Documents\\NetBeansProjects\\Student.sqlite","root","");
      } catch (Exception ex ) {
         System.out.println(ex.getMessage());
      }
        return con;
   }
 }

